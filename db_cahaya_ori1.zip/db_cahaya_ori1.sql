-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2026 at 04:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_cahaya`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_sales_order`
--

CREATE TABLE `detail_sales_order` (
  `id` int(11) NOT NULL,
  `order_no` varchar(30) DEFAULT NULL,
  `bom_id` varchar(20) DEFAULT NULL,
  `inventory_id` varchar(50) DEFAULT NULL,
  `inventory_name` varchar(255) DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `uom` varchar(20) DEFAULT NULL,
  `quantity_pack` decimal(15,2) DEFAULT 0.00,
  `quantity_detail` decimal(15,2) DEFAULT 0.00,
  `uom_pack` varchar(20) DEFAULT NULL,
  `uom_detail` varchar(20) DEFAULT NULL,
  `price_unit` decimal(15,2) DEFAULT 0.00,
  `price` decimal(15,2) DEFAULT 0.00,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_sales_order`
--

INSERT INTO `detail_sales_order` (`id`, `order_no`, `bom_id`, `inventory_id`, `inventory_name`, `quantity`, `uom`, `quantity_pack`, `quantity_detail`, `uom_pack`, `uom_detail`, `price_unit`, `price`, `subtotal`, `remarks`) VALUES
(15, 'SO.2026FC06.00001', NULL, 'CP-FG/PE-1-000005', 'PE ROLL STOKAN 0.1500X150X100 M PAKAI UV 5%', 1.00, 'KG', 1.00, 0.00, 'KG', '', 1000.00, 1000.00, 1000.00, 'TES1'),
(16, 'SO.2026FC06.00001', NULL, 'CP-FG/PE-1-000004', 'PE ROLL STOKAN 0.1500X150X51 M PAKAI UV 14%', 1.00, 'KG', 1.00, 0.00, 'KG', '', 2000.00, 2000.00, 2000.00, 'TES2');

-- --------------------------------------------------------

--
-- Table structure for table `det_po`
--

CREATE TABLE `det_po` (
  `id` int(11) NOT NULL,
  `no_po` varchar(50) DEFAULT NULL,
  `ukuran` varchar(200) DEFAULT NULL,
  `jml_order` varchar(100) DEFAULT NULL,
  `harga` varchar(50) DEFAULT NULL,
  `harga_kg` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `det_po`
--

INSERT INTO `det_po` (`id`, `no_po`, `ukuran`, `jml_order`, `harga`, `harga_kg`) VALUES
(81, '001/PO/2026', 'PE ROLL STOKAN 0.1500X150X100 M PAKAI UV 5%', '1', '1000', 1000.00),
(82, '001/PO/2026', 'PE ROLL STOKAN 0.1500X150X51 M PAKAI UV 14%', '1', '2000', 2000.00);

-- --------------------------------------------------------

--
-- Table structure for table `det_sop`
--

CREATE TABLE `det_sop` (
  `id` int(11) NOT NULL,
  `sop_id` varchar(20) DEFAULT NULL,
  `inventory_id` varchar(50) DEFAULT NULL,
  `inventory_name` varchar(255) DEFAULT NULL,
  `qty` decimal(15,2) DEFAULT 0.00,
  `uom` varchar(20) DEFAULT NULL,
  `qty_pack` decimal(15,2) DEFAULT 0.00,
  `uom_detail` varchar(20) DEFAULT NULL,
  `price` decimal(15,2) DEFAULT 0.00,
  `density` decimal(10,4) DEFAULT 0.0000,
  `remarks` text DEFAULT NULL,
  `previous_inventory` varchar(50) DEFAULT NULL,
  `previous_inventory_name` varchar(255) DEFAULT NULL,
  `component` varchar(100) DEFAULT NULL,
  `value` decimal(15,2) DEFAULT 0.00,
  `shipment_due_date` date DEFAULT NULL,
  `remarks_shipment` text DEFAULT NULL,
  `berat_jenis_potong` decimal(15,4) DEFAULT 0.0000,
  `spec_potong` varchar(255) DEFAULT NULL,
  `ukuran_potong` varchar(100) DEFAULT NULL,
  `jml_order_potong` decimal(15,2) DEFAULT 0.00,
  `isi_pakbal_potong` varchar(100) DEFAULT NULL,
  `keterangan_potong` text DEFAULT NULL,
  `tgl_produksi_potong` date DEFAULT NULL,
  `no_mesin_potong` varchar(50) DEFAULT NULL,
  `nat_warna_potong` varchar(100) DEFAULT NULL,
  `berat_rol_warna` decimal(15,4) DEFAULT 0.0000,
  `code_potong` varchar(100) DEFAULT NULL,
  `jarak_seal` decimal(15,2) DEFAULT 0.00,
  `berat_jenis_rol` decimal(15,4) DEFAULT 0.0000,
  `ukuran_rol` varchar(100) DEFAULT NULL,
  `berat_rol` decimal(15,4) DEFAULT 0.0000,
  `isi_bal_rol` varchar(100) DEFAULT NULL,
  `jml_order_rol` decimal(15,2) DEFAULT 0.00,
  `treat_rol` varchar(50) DEFAULT NULL,
  `nat_warna_rol` varchar(100) DEFAULT NULL,
  `bobin_krepyak_rol` varchar(100) DEFAULT NULL,
  `kirim_las_rol` varchar(100) DEFAULT NULL,
  `standar_cek_rol` varchar(100) DEFAULT NULL,
  `gramatur_asli_rol` decimal(15,4) DEFAULT 0.0000,
  `tebal_asli_rol` decimal(15,4) DEFAULT 0.0000,
  `spec_rol` varchar(255) DEFAULT NULL,
  `gramatur_rol` decimal(15,4) DEFAULT 0.0000,
  `tebal_rol` decimal(15,4) DEFAULT 0.0000,
  `keterangan_rol` text DEFAULT NULL,
  `gramatur_plus_rol` decimal(15,4) DEFAULT 0.0000,
  `gramatur_min_rol` decimal(15,4) DEFAULT 0.0000,
  `tebal_plus_rol` decimal(15,4) DEFAULT 0.0000,
  `tebal_minus_rol` decimal(15,4) DEFAULT 0.0000,
  `tgl_produksi_rol` date DEFAULT NULL,
  `no_mesin_rol` varchar(50) DEFAULT NULL,
  `code_rol` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `det_sop`
--

INSERT INTO `det_sop` (`id`, `sop_id`, `inventory_id`, `inventory_name`, `qty`, `uom`, `qty_pack`, `uom_detail`, `price`, `density`, `remarks`, `previous_inventory`, `previous_inventory_name`, `component`, `value`, `shipment_due_date`, `remarks_shipment`, `berat_jenis_potong`, `spec_potong`, `ukuran_potong`, `jml_order_potong`, `isi_pakbal_potong`, `keterangan_potong`, `tgl_produksi_potong`, `no_mesin_potong`, `nat_warna_potong`, `berat_rol_warna`, `code_potong`, `jarak_seal`, `berat_jenis_rol`, `ukuran_rol`, `berat_rol`, `isi_bal_rol`, `jml_order_rol`, `treat_rol`, `nat_warna_rol`, `bobin_krepyak_rol`, `kirim_las_rol`, `standar_cek_rol`, `gramatur_asli_rol`, `tebal_asli_rol`, `spec_rol`, `gramatur_rol`, `tebal_rol`, `keterangan_rol`, `gramatur_plus_rol`, `gramatur_min_rol`, `tebal_plus_rol`, `tebal_minus_rol`, `tgl_produksi_rol`, `no_mesin_rol`, `code_rol`) VALUES
(11, 'CP-SOP/2026/00001', 'CP-FG/PE-1-000005', 'PE ROLL STOKAN 0.1500X150X100 M PAKAI UV 5%', 1.00, 'KG', 1.00, 'KG', 1000.00, 0.0000, 'TES1', NULL, NULL, NULL, 0.00, NULL, NULL, 0.0000, 'Gram:+/-3% Tebal:+/-10%', ' 0.1500X150X100 M ', 1.00, '50 LB/BAL', 'KW 1', NULL, '', '', 0.0000, '', 0.00, 0.0000, ' 0.1500X150X100 M', 0.8300, '', 1.00, 'Non Treat', '', '', '', '', 9.9900, 2.2000, '', 0.0000, 0.0000, '', 0.0000, 0.0000, 0.0000, 0.0000, NULL, '', ''),
(12, 'CP-SOP/2026/00001', 'CP-FG/PE-1-000004', 'PE ROLL STOKAN 0.1500X150X51 M PAKAI UV 14%', 1.00, 'KG', 1.00, 'KG', 2000.00, 0.0000, 'TES2', NULL, NULL, NULL, 0.00, NULL, NULL, 0.0000, 'Gram:+/-3% Tebal:+/-10%', ' 0.1500X150X100 M ', 1.00, '50 LB/BAL', 'KW 1', NULL, '', '', 0.0000, '', 0.00, 0.0000, ' 0.1500X150X100 M', 0.8300, '', 1.00, 'Non Treat', '', '', '', '', 9.9900, 2.2000, '', 0.0000, 0.0000, '', 0.0000, 0.0000, 0.0000, 0.0000, NULL, '', ''),
(23, 'CP-SOP/2026/00002', 'CP-FG/PE-1-000005', 'PE ROLL STOKAN 0.1500X150X100 M PAKAI UV 5%', 1.00, 'KG', 1.00, 'KG', 1000.00, 0.0000, 'TES1', NULL, NULL, NULL, 0.00, NULL, NULL, 0.0000, 'Gram:+/-3% Tebal:+/-10%', ' 0.1500X150X100 M ', 1.00, '50 LB/BAL', 'KW 1 Panjang 59', NULL, '', '', 0.0000, '', 0.00, 0.0000, ' 0.1500X150X100 M', 0.8300, '', 1.00, 'Non Treat', '', '', '', '', 9.9900, 2.2000, '', 0.0000, 0.0000, '', 0.0000, 0.0000, 0.0000, 0.0000, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `head_sales_order`
--

CREATE TABLE `head_sales_order` (
  `order_no` varchar(20) NOT NULL,
  `order_date` date DEFAULT NULL,
  `export_flag` varchar(10) DEFAULT 'Unchecked',
  `po` varchar(50) DEFAULT NULL,
  `sop` varchar(30) DEFAULT NULL,
  `sop_date` date DEFAULT NULL,
  `marketing_id` varchar(20) DEFAULT NULL,
  `sales_id` varchar(20) DEFAULT NULL,
  `customer_id` varchar(20) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_address` text DEFAULT NULL,
  `customer_city` varchar(100) DEFAULT NULL,
  `station` varchar(50) DEFAULT 'Factory',
  `shipment_due_date` date DEFAULT NULL,
  `shipment_location` text DEFAULT NULL,
  `tolerance` decimal(10,2) DEFAULT 10.00,
  `backward_calculation` varchar(10) DEFAULT 'Unchecked',
  `vat` varchar(20) DEFAULT 'None',
  `payment_term` varchar(20) DEFAULT NULL,
  `payment_type` varchar(20) DEFAULT NULL,
  `days` int(11) DEFAULT 30,
  `currency` varchar(10) DEFAULT 'IDR',
  `kurs` decimal(10,4) DEFAULT 1.0000,
  `allow_auto_correct` varchar(10) DEFAULT 'Unchecked',
  `remarks` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Open',
  `approval_status` varchar(20) DEFAULT 'Pending',
  `grand_total` decimal(15,2) DEFAULT 0.00,
  `down_payment` decimal(15,2) DEFAULT 0.00,
  `create_user` varchar(50) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_modified` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `head_sales_order`
--

INSERT INTO `head_sales_order` (`order_no`, `order_date`, `export_flag`, `po`, `sop`, `sop_date`, `marketing_id`, `sales_id`, `customer_id`, `customer_name`, `customer_address`, `customer_city`, `station`, `shipment_due_date`, `shipment_location`, `tolerance`, `backward_calculation`, `vat`, `payment_term`, `payment_type`, `days`, `currency`, `kurs`, `allow_auto_correct`, `remarks`, `status`, `approval_status`, `grand_total`, `down_payment`, `create_user`, `date_created`, `user_modified`, `date_modified`) VALUES
('SO.2026FC06.00001', '2026-06-08', 'Unchecked', '001/PO/2026', NULL, NULL, 'MKT004', 'SAL004', 'CUST002', 'BAMBANG', 'Jl. Raya Darmo No. 45', 'Surabaya', 'FACTORY', '2026-06-09', 'Jl. Raya Darmo No. 45', 10.00, 'Unchecked', 'None', 'Franco', 'Cash', 30, 'IDR', 1.0000, 'Unchecked', 'TES SO', 'Open', 'Approve', 3000.00, 0.00, 'admin', '2026-06-08 03:49:29', 'admin', '2026-06-08 09:18:35');

--
-- Triggers `head_sales_order`
--
DELIMITER $$
CREATE TRIGGER `update_so_modified` BEFORE UPDATE ON `head_sales_order` FOR EACH ROW BEGIN
    SET NEW.date_modified = NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `head_sop`
--

CREATE TABLE `head_sop` (
  `sop_id` varchar(20) NOT NULL,
  `sop_date` date DEFAULT NULL,
  `target_date` date DEFAULT NULL,
  `no_urut_roll` varchar(50) DEFAULT NULL,
  `no_urut_potong` varchar(50) DEFAULT NULL,
  `order_no` varchar(30) DEFAULT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `old_code` varchar(50) DEFAULT NULL,
  `po_no` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Open',
  `approval_status` varchar(20) DEFAULT 'Pending',
  `create_user` varchar(100) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_modified` varchar(100) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `head_sop`
--

INSERT INTO `head_sop` (`sop_id`, `sop_date`, `target_date`, `no_urut_roll`, `no_urut_potong`, `order_no`, `customer`, `old_code`, `po_no`, `remarks`, `status`, `approval_status`, `create_user`, `date_created`, `user_modified`, `date_modified`) VALUES
('CP-SOP/2026/00001', '2026-06-08', '2026-06-09', '', '', 'SO.2026FC06.00001', 'BAMBANG', '1234', NULL, 'TES SO', 'Open', 'Pending', 'admin', '2026-06-08 05:45:19', NULL, NULL),
('CP-SOP/2026/00002', '2026-06-08', '2026-06-09', '', '', 'SO.2026FC06.00001', 'BAMBANG', '1234', NULL, 'TES SO', 'Open', 'Pending', 'admin', '2026-06-08 05:50:11', 'admin', '2026-06-08 14:15:51');

--
-- Triggers `head_sop`
--
DELIMITER $$
CREATE TRIGGER `update_sop_modified` BEFORE UPDATE ON `head_sop` FOR EACH ROW BEGIN
    SET NEW.date_modified = NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `hed_po`
--

CREATE TABLE `hed_po` (
  `id` int(11) NOT NULL,
  `no_po` varchar(50) DEFAULT NULL,
  `tgl_order` date DEFAULT NULL,
  `customer` varchar(100) DEFAULT NULL,
  `customer_id` varchar(20) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hed_po`
--

INSERT INTO `hed_po` (`id`, `no_po`, `tgl_order`, `customer`, `customer_id`, `created_by`, `created_at`) VALUES
(20, '001/PO/2026', '2026-06-08', 'BAMBANG', 'CUST002', 'admin', '2026-06-07 20:49:29');

-- --------------------------------------------------------

--
-- Table structure for table `m_category`
--

CREATE TABLE `m_category` (
  `categori_id` varchar(20) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `parent_code` varchar(50) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_category`
--

INSERT INTO `m_category` (`categori_id`, `name`, `remarks`, `parent_code`, `type`) VALUES
('CAT001', 'AFALAN', 'AFALAN', '', 'AFALAN-AFALAN'),
('CAT002', 'BAHAN PACKING', '-', '', 'BAHAN PACKING--'),
('CAT003', 'BIJI PLASTIK', '-', '', 'BIJI PLASTIK--'),
('CAT004', 'BOX', 'KERTAS BOX', '', 'BOX KERTAS'),
('CAT005', 'HD', 'GRUP HD POTONG ROLL', '', 'HD-GROUP HD POTONG'),
('CAT006', 'HD KRESEK', '-', 'HD KRESEK', 'HD KRESEK--'),
('CAT007', 'HD PKL', '-', '', 'HD PKL--'),
('CAT008', 'HD POTONG', '-', 'HD', 'HD POTONG'),
('CAT009', 'HD POTONG WARNA', '-', 'HD WARNA', 'HD POTONG WARNA--'),
('CAT010', 'HD ROLL', '-', 'HD', 'HD ROLL--'),
('CAT011', 'HD ROLL WARNA', '-', 'HD WARNA', 'HD ROLL WARNA--'),
('CAT012', 'HD SABLON', 'GRUP HD WARNA', 'HD WARNA', 'HD SABLON--'),
('CAT013', 'IMPORT', '-', '', 'IMPORT--'),
('CAT014', 'JASA', '-', '', 'JAS--'),
('CAT015', 'KAOS', '-', '', 'KAOS--'),
('CAT016', 'KERTAS', '-', '', ''),
('CAT017', 'KERTAS FG', '-', 'KERTAS GRP', 'KERTAS FG--'),
('CAT018', 'KERTAS GRP', 'GROUP KERTAS', '', 'KERTAS GRP-GROUP KERTAS'),
('CAT019', 'LAIN-LAIN', '-', '', 'LAN-LAIN--'),
('CAT020', 'LAINNYA', '-', '', 'LAINNYA--'),
('CAT021', 'MESIN', 'MESIN PRODUKSI', '', 'MESIN-MESIN PRODUKSI'),
('CAT022', 'PE', 'GROUP PE', '', 'PE-GROUP PE'),
('CAT023', 'PE PKL', '-', 'PE', 'PE PKL--'),
('CAT024', 'PE POTONG', 'PE POTONG--', 'PE', ''),
('CAT025', 'PE POTONG WARNA', '-', 'PE WARNA', 'PE POTONG WARNA--'),
('CAT026', 'PE ROLL', '-', 'PE', 'PE ROLL--'),
('CAT027', 'PE ROLL WARNA', '-', 'PE WARNA', 'PE ROLL WARNA--'),
('CAT028', 'PE WARNA', 'GROUP PE WARNA', '', 'PE WARNA-GROUP PE WARNA'),
('CAT029', 'PP', 'GROUP PP', '', 'PP-GROUP PP'),
('CAT030', 'PP PKL', '-', 'PP', 'PP PKL--'),
('CAT031', 'PP POTONG', '-', 'PP', 'PP POTONG--'),
('CAT032', 'PP POTONG WARNA', '-', 'PP', 'PP POTONG WARNA--'),
('CAT033', 'PP ROLL', '-', 'PP', 'PP ROLL--'),
('CAT034', 'PP ROLL BOLA', '-', 'PP', 'PP ROLL BOLA--'),
('CAT035', 'PP ROLL WARNA', 'gabung dgn PP ROLL', 'PP', ''),
('CAT036', 'SABLON', 'SABLON PE & PP', 'SABLON', 'SABLON-SABLON PE & pp'),
('CAT037', 'SEDOTAN', '-', 'SEDOTAN', 'SEDOTAN--'),
('CAT038', 'SLONTONG', '-', 'SLONTONG', 'SLONTONG--'),
('CAT039', 'TALI KILO', '-', 'TALI KILO', 'TALI KILO--'),
('CAT040', 'TALI LOS', '-', 'CAT040', 'TALI LOS--'),
('CAT041', 'TERPAL', '-', '', 'TERPAL--'),
('CAT042', 'WARNA', '-', '', 'WARNA--'),
('CAT043', 'WINDER/BALNG2', 'SETENGAH JADI', '', 'WINDER/BALING2-SETENGAH JADI');

-- --------------------------------------------------------

--
-- Table structure for table `m_customer`
--

CREATE TABLE `m_customer` (
  `customer_id` varchar(20) NOT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `npwp_address` text DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_person_phone` varchar(50) DEFAULT NULL,
  `npwp` varchar(30) DEFAULT NULL,
  `id_number` varchar(30) DEFAULT NULL,
  `id_name` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `credit_limit` decimal(15,2) DEFAULT 0.00,
  `email` varchar(100) DEFAULT NULL,
  `old_code` varchar(50) DEFAULT NULL,
  `area_code` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `parent_id` varchar(50) DEFAULT NULL,
  `parent_customer` varchar(100) DEFAULT NULL,
  `id_tku` varchar(50) DEFAULT NULL,
  `bagian` varchar(50) DEFAULT NULL,
  `transaction_tax` varchar(100) DEFAULT NULL,
  `transaction_tax_child` varchar(100) DEFAULT NULL,
  `is_active` varchar(20) DEFAULT 'Checked',
  `user_created` varchar(100) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_modified` varchar(100) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_customer`
--

INSERT INTO `m_customer` (`customer_id`, `customer`, `city`, `address`, `npwp_address`, `contact_person`, `contact_person_phone`, `npwp`, `id_number`, `id_name`, `phone`, `fax`, `credit_limit`, `email`, `old_code`, `area_code`, `remarks`, `type`, `tax_type`, `parent_id`, `parent_customer`, `id_tku`, `bagian`, `transaction_tax`, `transaction_tax_child`, `is_active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
('C0000002', 'EVELYN', 'GRESIK', 'JL VETERAN NO 1', NULL, 'EVELIN', '-', NULL, '1234567890', 'EVELYN', '+62-21-530-7950', NULL, 0.00, 'EV@ptmcs.com', '12345678', 'GRESIK', 'TES', 'Lokal', NULL, '-', '-', NULL, 'Insurance', NULL, NULL, 'Checked', 'admin', '2026-05-28 05:05:15', 'admin', '2026-06-05 16:33:57'),
('C0000003', 'DARTO', 'PASURUAN', 'JL AHMAD YANI NO 2', NULL, '-', '-', NULL, '1234567890', 'DARTO', '+62-21-530-7950', NULL, 0.00, 'DARTO@gmail.com', '1234567', 'PASURUAN', 'TES', 'Lokal', NULL, '-', '-', NULL, 'Services (Consulting,IT,etc.)', NULL, NULL, 'Checked', 'admin', '2026-05-29 10:10:13', 'admin', '2026-06-05 16:33:12'),
('C0000004', 'CERRY', 'JAKARTA', 'JL. TOLL JAKARTA-CIKAMPEK KM.47 BLK.B-1 KIIC SUKALUYU TELUKJAMBE TIMUR KAB. KARAWANG JAWA BARAT 41361', NULL, 'AGUNG', '', NULL, '1234567890', 'CERRY', '081221691620', NULL, 0.00, 'CERRY@gmail.com', '123456', 'JAKARTA', '-', 'Lokal', NULL, '-', '-', NULL, 'Others/Miscellaneous', NULL, NULL, 'Checked', 'admin', '2026-06-02 06:30:50', 'admin', '2026-06-05 16:32:17'),
('CUST001', 'AGUS JAYA', 'MALANG', 'Jl. Sudirman No. 123', NULL, '123456', '', NULL, '1234567890', 'AGUS JAYA', '+62-21-530-7950', NULL, 0.00, 'bambang@gmail.com', '12345', 'MALANG', 'TES', 'Lokal', NULL, '', '', NULL, 'Others/Miscellaneous', NULL, NULL, 'Checked', NULL, '2026-05-26 10:51:26', 'admin', '2026-06-05 16:31:47'),
('CUST002', 'BAMBANG', 'Surabaya', 'Jl. Raya Darmo No. 45', NULL, '123456', '', NULL, '1234567890', 'BAMBANG', '+62-21-530-7950', NULL, 0.00, 'bambang@gmail.com', '1234', 'Surabaya', 'tes', 'Lokal', NULL, '', '', NULL, 'Others/Miscellaneous', NULL, NULL, 'Checked', NULL, '2026-05-26 10:51:26', 'admin', '2026-06-05 16:31:03'),
('CUST003', 'BUDI JAYA', 'Bandung', 'Jl. Asia Afrika No. 78', NULL, '', '', NULL, '1234567890', 'BUDI JAYA', '+62-21-530-7950', NULL, 0.00, '', '123', 'Bandung', 'tes', 'Lokal', NULL, '', '', NULL, 'Others/Miscellaneous', NULL, NULL, 'Checked', NULL, '2026-05-26 10:51:26', 'admin', '2026-06-05 16:30:05');

--
-- Triggers `m_customer`
--
DELIMITER $$
CREATE TRIGGER `update_customer_modified` BEFORE UPDATE ON `m_customer` FOR EACH ROW BEGIN
    SET NEW.date_modified = NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `m_gudang`
--

CREATE TABLE `m_gudang` (
  `gudang_id` varchar(20) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `station` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_gudang`
--

INSERT INTO `m_gudang` (`gudang_id`, `name`, `station`) VALUES
('FC-01', 'GUDANG BAHAN BAKU', 'FACTORY'),
('FC-02', 'GUDANG BARANG JADI 1', 'FACTORY'),
('FC-03', 'GUDANG MAKLOON', 'HEADQUARTER'),
('FC-04', 'GUDANG PRODUKSI', 'FACTORY'),
('FC-05', 'GUDANG BARANG JADI 2', 'FACTORY');

-- --------------------------------------------------------

--
-- Table structure for table `m_inventory`
--

CREATE TABLE `m_inventory` (
  `inventory_id` varchar(20) NOT NULL,
  `inventory_name` varchar(255) DEFAULT NULL,
  `uom` varchar(20) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `cap` varchar(50) DEFAULT NULL,
  `colour` varchar(50) DEFAULT NULL,
  `quality` varchar(50) DEFAULT NULL,
  `volume_default` decimal(12,4) DEFAULT 1.0000,
  `uom_pack` varchar(20) DEFAULT NULL,
  `conversion_rate` decimal(15,4) DEFAULT 1.0000,
  `base_uom` varchar(20) DEFAULT 'KG',
  `pack_uom` varchar(20) DEFAULT 'PCS',
  `tolerance` int(11) DEFAULT 0,
  `upper_tolerance` decimal(5,2) DEFAULT 0.00,
  `lower_tolerance` decimal(5,2) DEFAULT 0.00,
  `merk` varchar(100) DEFAULT NULL,
  `p` decimal(10,2) DEFAULT 0.00,
  `l` decimal(10,2) DEFAULT 0.00,
  `t` decimal(10,2) DEFAULT 0.00,
  `p2` decimal(10,2) DEFAULT 0.00,
  `density` decimal(10,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `supp_code` varchar(50) DEFAULT NULL,
  `re_order_point` decimal(12,2) DEFAULT 0.00,
  `minimum_stock` decimal(12,2) DEFAULT 0.00,
  `maximum_stock` decimal(12,2) DEFAULT 0.00,
  `shelf_life_days` int(11) DEFAULT 0,
  `is_sub` varchar(20) DEFAULT 'Unchecked',
  `is_job_order` varchar(20) DEFAULT 'Unchecked',
  `dont_show_at_w48` varchar(20) DEFAULT 'Unchecked',
  `stokan` varchar(20) DEFAULT 'Unchecked',
  `internal_name` varchar(255) DEFAULT NULL,
  `catalog` varchar(100) DEFAULT NULL,
  `part_no` varchar(100) DEFAULT NULL,
  `printing_type` varchar(100) DEFAULT NULL,
  `calculation` varchar(100) DEFAULT NULL,
  `nama_customer` varchar(255) DEFAULT NULL,
  `type_rm` varchar(100) DEFAULT NULL,
  `tebal` decimal(10,4) DEFAULT 0.0000,
  `ukuran` varchar(100) DEFAULT NULL,
  `strength` varchar(100) DEFAULT NULL,
  `create_user` varchar(100) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_modified` varchar(100) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `ket_las` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_inventory`
--

INSERT INTO `m_inventory` (`inventory_id`, `inventory_name`, `uom`, `type`, `category`, `remarks`, `cap`, `colour`, `quality`, `volume_default`, `uom_pack`, `conversion_rate`, `base_uom`, `pack_uom`, `tolerance`, `upper_tolerance`, `lower_tolerance`, `merk`, `p`, `l`, `t`, `p2`, `density`, `description`, `origin`, `status`, `supp_code`, `re_order_point`, `minimum_stock`, `maximum_stock`, `shelf_life_days`, `is_sub`, `is_job_order`, `dont_show_at_w48`, `stokan`, `internal_name`, `catalog`, `part_no`, `printing_type`, `calculation`, `nama_customer`, `type_rm`, `tebal`, `ukuran`, `strength`, `create_user`, `date_created`, `user_modified`, `date_modified`, `ket_las`) VALUES
('CP-FG/PE-1-000001', 'PE ROLL STOKAN 0.1700X200X50 M PAKAI UV 5%', 'KG', 'Finish Good (FG)', 'CAT026', 'PE ROLL', '', '.NATURAL', 'UV1', 1.0000, 'KG', 1.0000, 'KG', 'KG', 10, 0.00, 0.00, '', 200.02, 50.00, 0.17, 0.00, 0.00, '', '', 'Active', '', 0.00, 0.00, 0.00, 0, 'Unchecked', 'Unchecked', 'Unchecked', 'Unchecked', '', '', '', '', '', '', '', 0.1700, '200X50 M', '', 'admin', '2026-06-06 05:30:57', 'admin', '2026-06-06 05:30:57', ''),
('CP-FG/PE-1-000002', 'PE ROLL STOKAN 0.2000X200X50 M PAKAI UV 5%', 'KG', 'Finish Good (FG)', 'CAT026', 'PE ROLL', '', '.NATURAL', 'UV1', 1.0000, 'KG', 1.0000, 'KG', 'KG', 10, 0.00, 0.00, '', 200.00, 49.98, 0.20, 0.00, 0.00, '', '', 'Active', '', 0.00, 0.00, 0.00, 0, 'Unchecked', 'Unchecked', 'Unchecked', 'Unchecked', '', '', '', '', '', '', '', 0.2001, '200X50 M', '', 'admin', '2026-06-06 05:53:12', 'admin', '2026-06-06 05:53:12', ''),
('CP-FG/PE-1-000003', 'PE ROLL STOKAN 0.2000X200X51 M PAKAI UV 14%', 'KG', 'Finish Good (FG)', 'CAT026', 'PE ROLL', '', '.NATURAL', 'UV1', 1.0000, 'KG', 1.0000, 'KG', 'KG', 10, 0.00, 0.00, '', 200.00, 51.00, 0.20, 0.00, 0.00, '', '', 'Active', '', 0.00, 0.00, 0.00, 0, 'Unchecked', 'Unchecked', 'Unchecked', 'Unchecked', '', '', '', '', '', '', '', 0.2000, '200X51 M', '', 'admin', '2026-06-06 08:17:19', 'admin', '2026-06-06 08:17:19', ''),
('CP-FG/PE-1-000004', 'PE ROLL STOKAN 0.1500X150X51 M PAKAI UV 14%', 'KG', 'Finish Good (FG)', 'CAT026', 'PE ROLL', '', '.NATURAL', 'UV1', 1.0000, 'KG', 1.0000, 'KG', 'KG', 10, 0.00, 0.00, '', 150.00, 51.00, 0.15, 0.00, 0.00, '', '', 'Active', '', 0.00, 0.00, 0.00, 0, 'Unchecked', 'Unchecked', 'Unchecked', 'Unchecked', '', '', '', '', '', '', '', 0.0000, '150X51 M', '', 'admin', '2026-06-06 08:19:36', 'admin', '2026-06-06 08:19:36', ''),
('CP-FG/PE-1-000005', 'PE ROLL STOKAN 0.1500X150X100 M PAKAI UV 5%', 'KG', 'Finish Good (FG)', 'CAT026', 'PE ROLL', '', '.NATURAL', 'UV1', 1.0000, 'KG', 1.0000, 'KG', 'KG', 10, 0.00, 0.00, '', 150.00, 100.00, 0.15, 0.00, 0.00, '', '', 'Active', '', 0.00, 0.00, 0.00, 0, 'Unchecked', 'Unchecked', 'Unchecked', 'Unchecked', '', '', '', '', '', '', '', 0.1503, '150X100 M', '', 'admin', '2026-06-06 08:35:02', 'admin', '2026-06-06 08:35:02', '');

--
-- Triggers `m_inventory`
--
DELIMITER $$
CREATE TRIGGER `update_inventory_modified` BEFORE UPDATE ON `m_inventory` FOR EACH ROW BEGIN
    SET NEW.date_modified = NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `m_marketing`
--

CREATE TABLE `m_marketing` (
  `marketing_id` varchar(20) NOT NULL,
  `marketing_name` varchar(100) DEFAULT NULL,
  `is_active` varchar(10) DEFAULT 'Checked',
  `create_user` varchar(50) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_modified` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_marketing`
--

INSERT INTO `m_marketing` (`marketing_id`, `marketing_name`, `is_active`, `create_user`, `date_created`, `user_modified`, `date_modified`) VALUES
('MKT001', 'Yanti', 'Checked', NULL, NULL, 'admin', '2026-06-06 08:44:58'),
('MKT002', 'Susi', 'Checked', NULL, NULL, 'admin', '2026-06-06 08:45:12'),
('MKT003', 'Rusmiaty', 'Checked', NULL, NULL, 'admin', '2026-06-06 08:45:49'),
('MKT004', 'Lutvia', 'Checked', 'gudang1', '2026-05-26 12:02:46', NULL, NULL),
('MKT005', 'Sugiono', 'Checked', 'admin', '2026-05-28 04:59:21', 'admin', '2026-06-06 08:46:32'),
('MKT006', 'Sri', 'Checked', 'admin', '2026-06-06 08:46:50', NULL, NULL),
('MKT007', 'Riska', 'Checked', 'admin', '2026-06-06 08:49:39', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_mesin`
--

CREATE TABLE `m_mesin` (
  `mesin_id` varchar(20) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `spec` text DEFAULT NULL,
  `manufactured_date` date DEFAULT NULL,
  `manufactured_by` varchar(100) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  `purchase_date` date DEFAULT NULL,
  `acc_reff` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `active` varchar(20) DEFAULT 'Active',
  `capacity` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_mesin`
--

INSERT INTO `m_mesin` (`mesin_id`, `name`, `spec`, `manufactured_date`, `manufactured_by`, `supplier`, `purchase_price`, `purchase_date`, `acc_reff`, `remarks`, `active`, `capacity`) VALUES
('MSN001', 'BANDERA', '', NULL, 'TAIWAN', '', 0.00, NULL, '', '', 'Checked', '');

-- --------------------------------------------------------

--
-- Table structure for table `m_sales`
--

CREATE TABLE `m_sales` (
  `sales_id` varchar(20) NOT NULL,
  `sales_name` varchar(100) DEFAULT NULL,
  `is_active` varchar(10) DEFAULT 'Checked',
  `create_user` varchar(50) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_modified` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_sales`
--

INSERT INTO `m_sales` (`sales_id`, `sales_name`, `is_active`, `create_user`, `date_created`, `user_modified`, `date_modified`) VALUES
('SAL001', 'Yanti', 'Checked', NULL, NULL, 'admin', '2026-06-06 08:50:07'),
('SAL002', 'Susi', 'Checked', NULL, NULL, 'admin', '2026-06-06 08:50:39'),
('SAL003', 'Rusmiaty', 'Checked', NULL, NULL, 'admin', '2026-06-06 08:50:51'),
('SAL004', 'Lutvia', 'Checked', 'gudang1', '2026-05-26 12:04:01', 'admin', '2026-06-06 08:51:19'),
('SAL005', 'Sugiono', 'Checked', 'gudang1', '2026-05-26 12:11:36', 'admin', '2026-06-06 08:52:31'),
('SAL006', 'Sri', 'Checked', 'gudang1', '2026-05-26 12:12:37', 'admin', '2026-06-06 09:01:30'),
('SAL007', 'Riska', 'Checked', 'admin', '2026-05-28 04:55:09', 'admin', '2026-06-06 09:01:40');

-- --------------------------------------------------------

--
-- Table structure for table `m_uom`
--

CREATE TABLE `m_uom` (
  `uom_id` varchar(20) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `is_active` varchar(10) DEFAULT 'Checked',
  `create_user` varchar(100) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_modified` varchar(100) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_uom`
--

INSERT INTO `m_uom` (`uom_id`, `unit`, `remarks`, `is_active`, `create_user`, `date_created`, `user_modified`, `date_modified`) VALUES
('UOM001', 'KG', 'KILOGRAM', 'Checked', NULL, '2026-05-28 13:04:17', 'admin', '2026-05-28 08:09:25'),
('UOM002', 'BAL', 'BAL', 'Checked', NULL, '2026-05-28 13:04:17', 'admin', '2026-05-30 09:29:45'),
('UOM003', 'ZAK', 'ZAK', 'Checked', NULL, '2026-05-28 13:04:17', 'admin', '2026-05-30 09:30:08'),
('UOM004', 'MT', 'METRIC TON', 'Checked', NULL, '2026-05-28 13:04:17', 'admin', '2026-05-30 09:30:36'),
('UOM005', 'LBR', 'LEMBAR', 'Checked', NULL, '2026-05-28 13:04:17', 'admin', '2026-05-30 09:30:47'),
('UOM006', 'PAK', 'PAK', 'Checked', NULL, '2026-05-28 13:04:17', 'admin', '2026-05-30 09:30:59'),
('UOM007', 'ROLL', 'ROLL', 'Checked', NULL, '2026-05-28 13:04:17', 'admin', '2026-05-30 09:31:09'),
('UOM008', 'MTR', 'METER', 'Checked', 'admin', '2026-05-30 09:31:19', NULL, NULL),
('UOM009', 'PCS', 'PCS', 'Checked', 'admin', '2026-05-30 09:31:26', NULL, NULL),
('UOM010', 'M2', 'METRE PERSEGI', 'Checked', 'admin', '2026-05-30 09:31:36', NULL, NULL),
('UOM011', 'IKT', 'IKAT', 'Checked', 'admin', '2026-05-30 09:31:46', NULL, NULL),
('UOM012', 'BOX', 'BOX', 'Checked', 'admin', '2026-05-30 09:31:54', NULL, NULL),
('UOM013', 'BAG', 'BAG', 'Checked', 'admin', '2026-05-30 09:32:01', NULL, NULL),
('UOM014', 'CTN', 'KARTON', 'Checked', 'admin', '2026-05-30 09:32:12', NULL, NULL),
('UOM015', 'DUS', 'DUS', 'Checked', 'admin', '2026-05-30 09:32:19', NULL, NULL),
('UOM016', 'KRG', 'KARUNG', 'Checked', 'admin', '2026-05-30 09:32:31', NULL, NULL),
('UOM017', 'UNIT', 'UNIT', 'Checked', 'admin', '2026-05-30 09:32:40', NULL, NULL),
('UOM018', 'PKS', 'PKS', 'Checked', 'admin', '2026-05-30 09:32:50', NULL, NULL),
('UOM019', 'SET', 'SET', 'Checked', 'admin', '2026-05-30 09:32:56', NULL, NULL),
('UOM020', 'LTR', 'LITER', 'Checked', 'admin', '2026-05-30 09:33:04', NULL, NULL),
('UOM021', 'GRM', 'GRAMATUR', 'Checked', 'admin', '2026-05-30 09:33:16', NULL, NULL),
('UOM022', 'SABLON', 'PRINTING/SABLON', 'Checked', 'admin', '2026-05-30 09:33:28', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_role`
--

CREATE TABLE `sys_role` (
  `id_role` int(11) NOT NULL,
  `nama_role` varchar(50) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sys_role`
--

INSERT INTO `sys_role` (`id_role`, `nama_role`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, 'IT Admin', 'Memiliki akses penuh ke seluruh sistem termasuk konfigurasi server dan user akses', '2026-05-21 12:12:38', '2026-05-21 12:12:38'),
(2, 'Marketing', 'Mengelola master data customer, supplier, inventory, category, gudang, mesin, dan transaksi sales', '2026-05-21 12:12:38', '2026-05-21 12:12:38'),
(3, 'Finance', 'Mengelola invoice, retur invoice, pembayaran, downpayment, titip uang, dan laporan piutang', '2026-05-21 12:12:38', '2026-05-21 12:12:38');

-- --------------------------------------------------------

--
-- Table structure for table `sys_users`
--

CREATE TABLE `sys_users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_role` int(11) NOT NULL,
  `is_active` varchar(20) DEFAULT 'Checked',
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sys_users`
--

INSERT INTO `sys_users` (`id_user`, `username`, `password`, `id_role`, `is_active`, `nama_lengkap`, `email`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$L14B522U.3qHv0Wkrht.vuHt6HrTgoF4BORSYOG0anO6wEWsZm0CW', 1, 'Checked', 'Administrator', 'admin@cahaya.com', '2026-05-21 12:12:38', '2026-05-21 13:04:10'),
(2, 'marketing', '$2y$10$L14B522U.3qHv0Wkrht.vuHt6HrTgoF4BORSYOG0anO6wEWsZm0CW', 2, 'Checked', 'Marketing User', 'marketing@cahaya.com', '2026-05-21 12:12:38', '2026-05-21 13:06:13'),
(3, 'finance', '$2y$10$L14B522U.3qHv0Wkrht.vuHt6HrTgoF4BORSYOG0anO6wEWsZm0CW', 3, 'Checked', 'Finance User', 'finance@cahaya.com', '2026-05-21 12:12:38', '2026-05-21 13:06:20');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_inventory_full`
-- (See below for the actual view)
--
CREATE TABLE `v_inventory_full` (
`inventory_id` varchar(20)
,`inventory_name` varchar(255)
,`uom` varchar(20)
,`type` varchar(50)
,`category` varchar(100)
,`remarks` text
,`cap` varchar(50)
,`colour` varchar(50)
,`quality` varchar(50)
,`volume_default` decimal(12,4)
,`uom_pack` varchar(20)
,`tolerance` int(11)
,`upper_tolerance` decimal(5,2)
,`lower_tolerance` decimal(5,2)
,`merk` varchar(100)
,`p` decimal(10,2)
,`l` decimal(10,2)
,`t` decimal(10,2)
,`p2` decimal(10,2)
,`density` decimal(10,2)
,`description` text
,`origin` varchar(50)
,`status` varchar(20)
,`supp_code` varchar(50)
,`re_order_point` decimal(12,2)
,`minimum_stock` decimal(12,2)
,`maximum_stock` decimal(12,2)
,`shelf_life_days` int(11)
,`is_sub` varchar(20)
,`is_job_order` varchar(20)
,`dont_show_at_w48` varchar(20)
,`stokan` varchar(20)
,`internal_name` varchar(255)
,`catalog` varchar(100)
,`part_no` varchar(100)
,`printing_type` varchar(100)
,`calculation` varchar(100)
,`nama_customer` varchar(255)
,`type_rm` varchar(100)
,`tebal` decimal(10,4)
,`ukuran` varchar(100)
,`strength` varchar(100)
,`create_user` varchar(100)
,`date_created` datetime
,`user_modified` varchar(100)
,`date_modified` datetime
,`ket_las` text
,`category_name` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_sales_order_full`
-- (See below for the actual view)
--
CREATE TABLE `v_sales_order_full` (
`order_no` varchar(20)
,`order_date` date
,`export_flag` varchar(10)
,`po` varchar(50)
,`sop` varchar(30)
,`sop_date` date
,`marketing_id` varchar(20)
,`sales_id` varchar(20)
,`customer_id` varchar(20)
,`customer_name` varchar(255)
,`customer_address` text
,`customer_city` varchar(100)
,`station` varchar(50)
,`shipment_due_date` date
,`shipment_location` text
,`tolerance` decimal(10,2)
,`backward_calculation` varchar(10)
,`vat` varchar(20)
,`payment_term` varchar(20)
,`payment_type` varchar(20)
,`days` int(11)
,`currency` varchar(10)
,`allow_auto_correct` varchar(10)
,`remarks` text
,`status` varchar(20)
,`approval_status` varchar(20)
,`grand_total` decimal(15,2)
,`down_payment` decimal(15,2)
,`create_user` varchar(50)
,`date_created` datetime
,`user_modified` varchar(50)
,`date_modified` datetime
,`marketing_name` varchar(100)
,`sales_name` varchar(100)
,`customer_name_from_master` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_sop_full`
-- (See below for the actual view)
--
CREATE TABLE `v_sop_full` (
`sop_id` varchar(20)
,`sop_date` date
,`target_date` date
,`no_urut_roll` varchar(50)
,`no_urut_potong` varchar(50)
,`order_no` varchar(30)
,`customer` varchar(255)
,`old_code` varchar(50)
,`po_no` varchar(50)
,`remarks` text
,`status` varchar(20)
,`approval_status` varchar(20)
,`create_user` varchar(100)
,`date_created` datetime
,`user_modified` varchar(100)
,`date_modified` datetime
,`order_date` date
,`sales_order_customer` varchar(255)
,`so_status` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure for view `v_inventory_full`
--
DROP TABLE IF EXISTS `v_inventory_full`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_inventory_full`  AS SELECT `i`.`inventory_id` AS `inventory_id`, `i`.`inventory_name` AS `inventory_name`, `i`.`uom` AS `uom`, `i`.`type` AS `type`, `i`.`category` AS `category`, `i`.`remarks` AS `remarks`, `i`.`cap` AS `cap`, `i`.`colour` AS `colour`, `i`.`quality` AS `quality`, `i`.`volume_default` AS `volume_default`, `i`.`uom_pack` AS `uom_pack`, `i`.`tolerance` AS `tolerance`, `i`.`upper_tolerance` AS `upper_tolerance`, `i`.`lower_tolerance` AS `lower_tolerance`, `i`.`merk` AS `merk`, `i`.`p` AS `p`, `i`.`l` AS `l`, `i`.`t` AS `t`, `i`.`p2` AS `p2`, `i`.`density` AS `density`, `i`.`description` AS `description`, `i`.`origin` AS `origin`, `i`.`status` AS `status`, `i`.`supp_code` AS `supp_code`, `i`.`re_order_point` AS `re_order_point`, `i`.`minimum_stock` AS `minimum_stock`, `i`.`maximum_stock` AS `maximum_stock`, `i`.`shelf_life_days` AS `shelf_life_days`, `i`.`is_sub` AS `is_sub`, `i`.`is_job_order` AS `is_job_order`, `i`.`dont_show_at_w48` AS `dont_show_at_w48`, `i`.`stokan` AS `stokan`, `i`.`internal_name` AS `internal_name`, `i`.`catalog` AS `catalog`, `i`.`part_no` AS `part_no`, `i`.`printing_type` AS `printing_type`, `i`.`calculation` AS `calculation`, `i`.`nama_customer` AS `nama_customer`, `i`.`type_rm` AS `type_rm`, `i`.`tebal` AS `tebal`, `i`.`ukuran` AS `ukuran`, `i`.`strength` AS `strength`, `i`.`create_user` AS `create_user`, `i`.`date_created` AS `date_created`, `i`.`user_modified` AS `user_modified`, `i`.`date_modified` AS `date_modified`, `i`.`ket_las` AS `ket_las`, `c`.`name` AS `category_name` FROM (`m_inventory` `i` left join `m_category` `c` on(`i`.`category` = `c`.`categori_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `v_sales_order_full`
--
DROP TABLE IF EXISTS `v_sales_order_full`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sales_order_full`  AS SELECT `h`.`order_no` AS `order_no`, `h`.`order_date` AS `order_date`, `h`.`export_flag` AS `export_flag`, `h`.`po` AS `po`, `h`.`sop` AS `sop`, `h`.`sop_date` AS `sop_date`, `h`.`marketing_id` AS `marketing_id`, `h`.`sales_id` AS `sales_id`, `h`.`customer_id` AS `customer_id`, `h`.`customer_name` AS `customer_name`, `h`.`customer_address` AS `customer_address`, `h`.`customer_city` AS `customer_city`, `h`.`station` AS `station`, `h`.`shipment_due_date` AS `shipment_due_date`, `h`.`shipment_location` AS `shipment_location`, `h`.`tolerance` AS `tolerance`, `h`.`backward_calculation` AS `backward_calculation`, `h`.`vat` AS `vat`, `h`.`payment_term` AS `payment_term`, `h`.`payment_type` AS `payment_type`, `h`.`days` AS `days`, `h`.`currency` AS `currency`, `h`.`allow_auto_correct` AS `allow_auto_correct`, `h`.`remarks` AS `remarks`, `h`.`status` AS `status`, `h`.`approval_status` AS `approval_status`, `h`.`grand_total` AS `grand_total`, `h`.`down_payment` AS `down_payment`, `h`.`create_user` AS `create_user`, `h`.`date_created` AS `date_created`, `h`.`user_modified` AS `user_modified`, `h`.`date_modified` AS `date_modified`, `m`.`marketing_name` AS `marketing_name`, `s`.`sales_name` AS `sales_name`, `c`.`customer` AS `customer_name_from_master` FROM (((`head_sales_order` `h` left join `m_marketing` `m` on(`h`.`marketing_id` = `m`.`marketing_id`)) left join `m_sales` `s` on(`h`.`sales_id` = `s`.`sales_id`)) left join `m_customer` `c` on(`h`.`customer_id` = `c`.`customer_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `v_sop_full`
--
DROP TABLE IF EXISTS `v_sop_full`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sop_full`  AS SELECT `h`.`sop_id` AS `sop_id`, `h`.`sop_date` AS `sop_date`, `h`.`target_date` AS `target_date`, `h`.`no_urut_roll` AS `no_urut_roll`, `h`.`no_urut_potong` AS `no_urut_potong`, `h`.`order_no` AS `order_no`, `h`.`customer` AS `customer`, `h`.`old_code` AS `old_code`, `h`.`po_no` AS `po_no`, `h`.`remarks` AS `remarks`, `h`.`status` AS `status`, `h`.`approval_status` AS `approval_status`, `h`.`create_user` AS `create_user`, `h`.`date_created` AS `date_created`, `h`.`user_modified` AS `user_modified`, `h`.`date_modified` AS `date_modified`, `s`.`order_date` AS `order_date`, `s`.`customer_name` AS `sales_order_customer`, `s`.`status` AS `so_status` FROM (`head_sop` `h` left join `head_sales_order` `s` on(`h`.`order_no` = `s`.`order_no`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_sales_order`
--
ALTER TABLE `detail_sales_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_no` (`order_no`),
  ADD KEY `inventory_id` (`inventory_id`);

--
-- Indexes for table `det_po`
--
ALTER TABLE `det_po`
  ADD PRIMARY KEY (`id`),
  ADD KEY `no_po` (`no_po`);

--
-- Indexes for table `det_sop`
--
ALTER TABLE `det_sop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_det_sop_sop_id` (`sop_id`),
  ADD KEY `idx_det_sop_inventory` (`inventory_id`);

--
-- Indexes for table `head_sales_order`
--
ALTER TABLE `head_sales_order`
  ADD PRIMARY KEY (`order_no`),
  ADD KEY `marketing_id` (`marketing_id`),
  ADD KEY `sales_id` (`sales_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `head_sop`
--
ALTER TABLE `head_sop`
  ADD PRIMARY KEY (`sop_id`),
  ADD KEY `idx_sop_order_no` (`order_no`),
  ADD KEY `idx_sop_customer` (`customer`),
  ADD KEY `idx_sop_status` (`status`),
  ADD KEY `idx_sop_date` (`sop_date`);

--
-- Indexes for table `hed_po`
--
ALTER TABLE `hed_po`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `no_po` (`no_po`);

--
-- Indexes for table `m_category`
--
ALTER TABLE `m_category`
  ADD PRIMARY KEY (`categori_id`);

--
-- Indexes for table `m_customer`
--
ALTER TABLE `m_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `m_gudang`
--
ALTER TABLE `m_gudang`
  ADD PRIMARY KEY (`gudang_id`);

--
-- Indexes for table `m_inventory`
--
ALTER TABLE `m_inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `m_marketing`
--
ALTER TABLE `m_marketing`
  ADD PRIMARY KEY (`marketing_id`);

--
-- Indexes for table `m_mesin`
--
ALTER TABLE `m_mesin`
  ADD PRIMARY KEY (`mesin_id`);

--
-- Indexes for table `m_sales`
--
ALTER TABLE `m_sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `m_uom`
--
ALTER TABLE `m_uom`
  ADD PRIMARY KEY (`uom_id`);

--
-- Indexes for table `sys_role`
--
ALTER TABLE `sys_role`
  ADD PRIMARY KEY (`id_role`);

--
-- Indexes for table `sys_users`
--
ALTER TABLE `sys_users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `id_role` (`id_role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_sales_order`
--
ALTER TABLE `detail_sales_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `det_po`
--
ALTER TABLE `det_po`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `det_sop`
--
ALTER TABLE `det_sop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `hed_po`
--
ALTER TABLE `hed_po`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sys_role`
--
ALTER TABLE `sys_role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sys_users`
--
ALTER TABLE `sys_users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_sales_order`
--
ALTER TABLE `detail_sales_order`
  ADD CONSTRAINT `detail_sales_order_ibfk_1` FOREIGN KEY (`order_no`) REFERENCES `head_sales_order` (`order_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_sales_order_ibfk_2` FOREIGN KEY (`inventory_id`) REFERENCES `m_inventory` (`inventory_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `det_sop`
--
ALTER TABLE `det_sop`
  ADD CONSTRAINT `det_sop_ibfk_1` FOREIGN KEY (`sop_id`) REFERENCES `head_sop` (`sop_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `det_sop_ibfk_2` FOREIGN KEY (`inventory_id`) REFERENCES `m_inventory` (`inventory_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `head_sales_order`
--
ALTER TABLE `head_sales_order`
  ADD CONSTRAINT `head_sales_order_ibfk_1` FOREIGN KEY (`marketing_id`) REFERENCES `m_marketing` (`marketing_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `head_sales_order_ibfk_2` FOREIGN KEY (`sales_id`) REFERENCES `m_sales` (`sales_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `head_sales_order_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `m_customer` (`customer_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `head_sop`
--
ALTER TABLE `head_sop`
  ADD CONSTRAINT `head_sop_ibfk_1` FOREIGN KEY (`order_no`) REFERENCES `head_sales_order` (`order_no`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `m_inventory`
--
ALTER TABLE `m_inventory`
  ADD CONSTRAINT `m_inventory_ibfk_1` FOREIGN KEY (`category`) REFERENCES `m_category` (`categori_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
